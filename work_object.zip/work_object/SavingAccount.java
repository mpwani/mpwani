import java.util.prefs.BackingStoreException;

public class SavingAccount {

    private int monthlyIntarestRaate;
    private int savingAccount;
    private int annualyIntarestRate;

    public int getmonthlyrate() {
        return monthlyIntarestRaate;
    }

    public int getsavingaccount() {
        return savingAccount;
    }

    public int gatannualyrate() {
        return annualyIntarestRate;
    }

    public void setmonthlyRateSaverONE(int balance1) {
        System.out.println("The interest rate per montly of saver1 " + balance1 / 12);
    }

    public void setannulyRateSaverONE(int balance1) {
        System.out.println("The annual interest Rate of saver1 " + balance1 * 4 / 100);
    }

    public void newbalanceSaverONEnextmonthly(int balance1) {
        System.out.println("The new balance of next Month of saver1 " + (balance1 - (balance1 * 4 / 100)));

    }

    public void setmonthlyRateSaverTWO(int balance2) {
        System.out.println("The interest rate per montly of saver2 " + balance2 / 12);
    }

    public void setannulyRateSaverTWO(int balance2) {
        System.out.println("The annual interest Rate of saver2 " + (balance2 * 4 / 12));
    }

    public void newbalanceSaverTWOnextmonthly(int balance2) {
        System.out.println("The new balance of next Month of saver2  " + (balance2 - (balance2 * 4 / 100)));
    }

    public void getnewannulayRateSaverONE(int balance1) {
        System.out.println("New rate of interest rate 5% is " + balance1 * 5 / 100);
    }

    public void getnewannulayRateSaverTWO(int balance2) {
        System.out.println("New rate of interest rate 5% is  " + balance2 * 5 / 100);
    }

    public static void main(String[] args) {
        System.out.println("*******The first holder of Saving Account********");
        SavingAccount saverone = new SavingAccount();
        saverone.setmonthlyRateSaverONE(2000);
        saverone.setannulyRateSaverONE(2000);
        saverone.newbalanceSaverONEnextmonthly(2000);
        saverone.getnewannulayRateSaverONE(2000);
        System.out.println();
        System.out.println("*********the second holder of Saving Account******");
        SavingAccount saver2 = new SavingAccount();
        saver2.setmonthlyRateSaverTWO(3000);
        saver2.setannulyRateSaverTWO(2000);
        saver2.newbalanceSaverTWOnextmonthly(3000);
        saver2.getnewannulayRateSaverTWO(3000);

    }

}
