public class Date {

    private int month;
    private int date;
    private int year;

    Date(int dateIn, int yearIn) {
        this.date = dateIn;
        this.year = yearIn;
        month = 1;

    }

    public int getdate() {
        return date;
    }

    public int geteyear() {
        return year;
    }

    public void setmonth(int monthIn) {
        if (monthIn < 13 && monthIn > 0) {
            System.out.println(monthIn + "/" + date + "/" + year);
        } else {
            System.out.println(month + "/" + date + "/" + year);
            monthIn = 1;
        }

    }

    public static void main(String[] args) {
        Date get = new Date(3, 1920);
        get.setmonth(7);
    }

}
