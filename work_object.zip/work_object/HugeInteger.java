import java.util.*;

public class HugeInteger {

    public void arrayHugeInteger() {
        int[] arrayInteger = new int[40];
       
        for (int i = 0; i < 40; i++) {
           
            
        }

    }

    public boolean addANDsubstracte() {
        int[] arrayInteger = new int[40];
        if (arrayInteger.length < 40) {
            return false;
        } else {
            System.out.println(arrayInteger.length + 40);
            return true;
        }
    }

    public boolean substracte() {
        int[] arrayInteger = new int[40];
        if (arrayInteger.length < 40) {
            return true;
        } else {
            System.out.println(arrayInteger.length - 40);
            return false;
        }

    }

    public static void main(String[] args) {
        HugeInteger get = new HugeInteger();
        System.out.println(get.substracte());
        System.out.println(get.addANDsubstracte());
    }

}
