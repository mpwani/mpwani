/**
 * Invoice
 */
public class Invoice {

    private String InvoiceNumber;
    private String Description;
    private int quantity;
    private int price;

    public Invoice(String InvoiceIn, String DescriptinIn, int quantityIn, int priceIn) {
        this.InvoiceNumber = InvoiceIn;
        this.Description = DescriptinIn;
        this.quantity = quantityIn;
        this.price = priceIn;
    }

    public int setprice() {
        return price;

    }

    public int setquntity() {
        return quantity;
    }

    public int getInvoiceAmount() {
        if (price < 0 || quantity < 0) {
            System.out.println("the price and quantity cn not be less then zero " + (quantity = 0));
            System.out.println("price can not be less then zero " + (price = 0));

        }

        return price * quantity;

    }

    public static void main(String[] args) {
        Invoice get = new Invoice(null, null, 12, -8);
        System.out.println("the total invoice amount is " + get.getInvoiceAmount());
    }

}