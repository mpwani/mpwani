public class Account {
    private String customername;
    private String accountname;
    private double balance;

    Account(String customerIn, String accountIn, double balance) {
        this.accountname = customerIn;
        this.customername = accountIn;
        balance = 0;

    }

    public String getaccountname() {
        return customername;
    }

    public String getcustomername() {
        return customername;
    }

    public void setdeposite(double deposite) {
        balance = balance + deposite;

    }

    public double setbalance(double withdrow) {
        if (balance > withdrow) {
            balance = balance - withdrow;
        } else {
            System.out.println(
                    "the balance can not withdrow due to account balance is less then amount withdrow " + withdrow);
        }
        return balance;
    }

    public static void main(String[] args) {
        Account get = new Account(null, null, 0);
        System.out.println("********Customer Bank Account*******");
        get.setdeposite(100);
        get.setbalance(900);
        System.out.println("the balance remain is " + get.balance);

    }

}
