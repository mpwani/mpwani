public class Babkbalance {
    private int datamember;
    private int initialbalance;
    private int currentbalance;
    private int balance = 0;

    public Babkbalance(int memberIn, int inititalIn, int currentIn) {
        this.datamember = memberIn;
        this.initialbalance = inititalIn;
        this.currentbalance = currentIn;

    }

    public int getinitialbalance() {
        return initialbalance;
    }

    public int getcurrentbalance() {
        return currentbalance;
    }

    public double getbalance() {
        if (balance >= 0) {
            balance = currentbalance + initialbalance;
            System.out.println("the total balance " + balance);
        } else {
            System.out.println("error massage");
        }
        return balance;
    }

    public double getremainbalance(double withdrow) {
        return balance - withdrow;

    }

    public void overdraft(double withdrow) {
        if (withdrow > balance) {
            System.out.println("debit balance exceed the account balance");
        }
    }

    public static void main(String[] args) {
        Babkbalance get = new Babkbalance(112, 0, 0);

        get.getbalance();
        System.out.println("the acount balance  " + get.getremainbalance(50));

    }

}
