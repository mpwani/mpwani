import java.sql.Blob;

public class Triangle {
    private int a;
    private int b;
    private int c;

    Triangle(int height, int base, int hypthenases) {
        this.a = height;
        this.b = base;
        this.c = hypthenases;
    }

    public int getheight() {
        return a;
    }

    public int getbase() {
        return b;
    }

    public int gethypthenas() {
        return c;
    }

    public boolean isTriangle() {
        if ((a + b) > c || (a + c) > b || (b + c) > a) {
            return true;
        } else {
            System.out.println("the triangle is not really a triangle ");
            return false;
        }
    }

    public double getArea() {
        return 0.5 * (a * b);
    }

    public static void main(String[] args) {

        Triangle get = new Triangle(0, 0, 0);
        System.out.println(get.isTriangle());
        System.out.println(get.getArea());
    }

}
