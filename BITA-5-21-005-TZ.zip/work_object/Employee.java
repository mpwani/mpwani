/**
 * Employee
 */
public class Employee {

    private String fname;
    private int salary;
    private int totalsalary = 0;

    Employee(String fnamIn, int salaryIn, int totalsalaryIn) {
        this.fname = fnamIn;
        this.salary = salaryIn;
        this.totalsalary = totalsalaryIn;

    }

    public String getfname() {
        return fname;
    }

    public int getsalary() {
        return salary;
    }

    public int gettotalsalary() {
        return totalsalary;
    }

    public void getmonthlysalary(int perday) {
        totalsalary = (salary * perday) + (salary + (10 / 100));
        System.out.println(" total salary per day " + totalsalary);

    }

    public double getyearsalary(int permonth) {
        return (totalsalary * permonth);
    }

    public static void main(String[] args) {
        Employee get = new Employee(null, 10, 0);
        get.getmonthlysalary(30);
        System.out.println("total asalary per year " + get.getyearsalary(12));

    }

}