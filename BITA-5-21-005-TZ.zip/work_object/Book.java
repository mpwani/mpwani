import java.util.Scanner;

public class Book {
    private String Bname;
    private String author;
    private  int ISBN;
    private  String publisher;
    public Book(String BnameIn,String authorIn, int isbnIn, String publisherIn){
        this.Bname = BnameIn;
        this.author = authorIn;
        this.ISBN = isbnIn;
        this.publisher = publisherIn;
    } 
    public String getBname(){
        return Bname;
    }
    public String getauthor(){
        return author;
    }
    public int getISBN(){
        return ISBN;
    }
    public String getpublisher(){
        return publisher;
    }
    public String getBookInfo(){
        return ("The name of the book is "+Bname+".The author is "+author+". the ISBN number is "+ISBN+" and the publisher is "+publisher);
    }
    public static void main(String[] args) {
        Book scanner = new Book("java", "masoud", 22, "mmanga");
        System.out.println(scanner.getBookInfo());
    
     String[] BookNameTest;
     BookNameTest = new String[30];
    Scanner keybord = new Scanner(System.in);
    for(int i = 0; i < BookNameTest.length;i++){
        System.out.println("Enter name");
        BookNameTest[i] = keybord.nextLine();
    
}
}
}