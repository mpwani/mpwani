public class Complex {
    private double realPart;
    private double imaginaryPart;

    Complex(double realPart, double imaginaryPart) {
        this.realPart = realPart;
        this.imaginaryPart = imaginaryPart;

    }

    public double getrealPart() {
        return realPart;
    }

    public double getimaginaryPart() {
        return imaginaryPart;
    }

    public void setAdd(double realPart, double imaginaryPart) {

        System.out.printf("the addition of two complex is %.1f + %1fi ", realPart, imaginaryPart);

    }

    public void setSubstraction(double realPart, double imaginaryPart) {
        System.out.printf("the substraction of two complex is %.1fi - %.1f ", imaginaryPart, realPart);
    }

    public static void main(String[] args) {
        Complex get = new Complex(30.4, 7.4);
        get.setAdd(30.7, 99.3);
        System.out.println();
        get.setSubstraction(33.7, 6.7);
    }

}
