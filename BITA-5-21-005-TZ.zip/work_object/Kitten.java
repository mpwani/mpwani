public class Kitten {
    private String name;
    private String owner;
    private int age;
    public Kitten(String nameIn, String ownerIn, int ageIn){
        this.name = nameIn;
        this.owner = ownerIn;
        this.age = ageIn;
    }
    public String getname(){
        return name;
    }
    public String getowner(){
        return owner;
    }
    public int getage(){
          age = 0;
        return age;
    }
    public int haveBirthday(){
        int have = age + 1;
        return have;
    }
    public String toString(){
        String display =( name +" is "+ haveBirthday()+ " and belong to "+owner);
        return display;
    }
    public static void main(String[] args) {
        Kitten scanner = new Kitten("Bob", "gregor samsa", -3);
        System.out.println(scanner.toString());
    }
}
