public class Rational {
    private int numerator = 0;
    private int denominator = 1;

    public Rational(int numeratorIn, int denominatorIn) {
        this.numerator = numeratorIn;
        this.denominator = denominatorIn;
    }

    public int getnumerator() {
        return numerator;
    }

    public int getdenominator() {
        return denominator;
    }

    public int Addition(int setnumerator, int setdenominator) {

        return numerator + denominator;
    }

    public int Subtraction(int setnumerator, int setdenominator) {
        return numerator - denominator;
    }

    public int Multiplication(int setnumerator, int denominator) {
        return (numerator * denominator);
    }

    public int Division(int setnumerator, int setdenominator) {
        return numerator / denominator;
    }

    public void Printing(int setnumerator, int setdenominator) {
        if (numerator > denominator) {
            System.out.println(numerator + "/" + denominator);
        } else {
            System.out.println("this function can not be relation ");
        }

    }

    public void PrintinginFloat(int setnumerator, int setdenominator) {
        if (numerator > denominator) {
            System.out.println("the form of a/b is " + numerator + "/" + denominator);
        } else {
            System.out.println("denomirator should be graeter then numerator");
        }
    }

    public static void main(String[] args) {
        Rational get = new Rational(115, 11);
        System.out.println("Addition is " + get.Addition(0, 0));
        System.out.println("Substraction is " + get.Subtraction(0, 0));
        System.out.println("Multiplication is " + get.Multiplication(0, 0));
        System.out.println("Division is " + get.Division(0, 0));
        get.Printing(0, 0);
        get.PrintinginFloat(0, 0);

    }
}
