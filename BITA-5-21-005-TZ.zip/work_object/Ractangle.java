/**
 * Ractangle
 */
public class Ractangle {

    private float length;
    private float width;

    // constractor
    Ractangle(float lengthIn, float widthIn) {
        this.length = lengthIn;
        this.width = widthIn;

    }

    public float getlength(Float lengthIn) {
        if (lengthIn < 0.0 && lengthIn < 20.0) {
            return lengthIn;
        }
        return length = 1.0f;

    }

    public float getwidth(float widthIn) {
        if (widthIn < 0.0 && widthIn < 20.0) {
            return widthIn;
        } else {
            return width = 1.0f;
        }

    }

    public float setarea() {
        return length * width;

    }

    public float setparametres() {

        return 2 * (length + width);
    }

    public static void main(String[] args) {
        Ractangle get = new Ractangle(2.7f, 35.8f);
        System.out.println(get.setarea());
        System.out.println(get.setparametres());
    }
}